/**
 * Created by Air on 2017/10/16.
 */


module.exports.handler = (event, context, callback) => {
  const response = {
    statusCode: 200
  };

  callback(null, response);
};